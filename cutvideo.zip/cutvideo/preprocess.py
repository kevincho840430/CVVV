import cv2

cap = cv2.VideoCapture('result_0603_1.avi')
#cap.set(1,inputframe)
i = 0
while(True):
  # 從攝影機擷取一張影像
  ret, frame = cap.read()

  # 顯示圖片
  cv2.imwrite("count_1/%d.jpg" % i, frame)
  print(i)
  #cv2.imshow('frame', frame)

  # 若按下 q 鍵則離開迴圈
  i+=1
  #if cv2.waitKey(30) & 0xFF == ord('q'):
    #break

# 釋放攝影機
cap.release()

# 關閉所有 OpenCV 視窗
cv2.destroyAllWindows()
