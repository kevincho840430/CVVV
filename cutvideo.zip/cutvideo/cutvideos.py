import numpy
import cv2

#demoroom

URL = "rtsp://admin:Csie3621@140.128.124.237/?channel=4"
URL2 = "rtsp://admin:Csie3621@140.128.124.237/?channel=5"

output_path="output/"
fourcc = cv2.VideoWriter_fourcc(*'XVID')

ipcam = cv2.VideoCapture(URL)
ipcam2 = cv2.VideoCapture(URL2)

##
h = int(ipcam.get(3))
w = int(ipcam.get(4))
fps = ipcam.get(5)
##
h2 = int(ipcam2.get(3))
w2 = int(ipcam2.get(4))
fps2 = ipcam2.get(5)

#label = 1

video_write1 = cv2.VideoWriter('cm1.avi',fourcc,8.0,(h,w))
video_write2 = cv2.VideoWriter('cm2.avi',fourcc,8.0,(h2,w2))


while True:
    ret, frame = ipcam.read()
    ret2, frame2 = ipcam2.read()


    cv2.namedWindow("frame",cv2.WINDOW_NORMAL)
    cv2.imshow('frame', frame)

    video_write1.write(frame)
    video_write2.write(frame2)

    #cv2.imwrite("C:/Users/pengwenyi/Desktop/demoroom/test7/v1/v1_%d.jpg" %label, frame)
    #cv2.imwrite("C:/Users/pengwenyi/Desktop/demoroom/test7/v2/v2_%d.jpg" %label, frame2)
    #label += 1
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

ipcam.release()

video_write1.release()
video_write2.release()

cv2.destroyAllWindows()
