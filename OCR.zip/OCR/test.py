from PIL import Image
import pytesseract
import cv2
img = cv2.imread('34.jpg')
img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
#cv2.imshow('11',img)
text = pytesseract.image_to_string(img,config='--psm 10 --oem 3 -c tessedit_char_whitelist=0123456789')
print(text)
