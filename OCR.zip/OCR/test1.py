from imutils.object_detection import non_max_suppression
import numpy as np
import pytesseract
import argparse
import cv2

#series 1
startX = 40
startY = 44
endX = 76
endY = 89

'''
startX = 40
startY = 44
endX = 76
endY = 89
'''
#series 2
# startX = 70
# startY = 724
# endX = 270
# endY = 770

image = cv2.imread('photo.jpg')
roi = image[startY:endY, startX:endX]
#text = 'hello'
text = pytesseract.image_to_string(roi)
cv2.rectangle(image, (startX, startY), (endX, endY),(0, 0, 255), 2)
cv2.putText(image, text, (startX, startY - 10),cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 255), 3)
print(text)
cv2.imshow('result', image)
cv2.imwrite('result_1.jpg',image)
cv2.waitKey(0)
cv2.destroyAllWindows()
